When the game shows a “Guardian Verification”, the Control Center solves it automatically as long as it is running. It is completely free, with no ClientKey to apply for or set up. The “Captcha” page in the Control Center also keeps a record of every attempt.

- Free for all users

## Where to find it

1. Control Center
2. Captcha
3. Captcha Records

The in-game switch is under F10 Helper menu › General Config › Guardian Verification.

## What it does

- While the Control Center is running, Guardian verification is recognized and passed automatically
- Uses Aion Helper's own recognition service: free, no key needed, and it picks the faster connection automatically
- Records the time, character, image, answer and result of every verification, and you can double-click to see the image
- Counts successes, failures and pending checks, with the success rate
- Return to Character Select to avoid verification: briefly goes back to character select to sidestep the check

## How to use it

1. Open the Control Center and keep it running.
2. In the game, press F10 › General Config and set “Return to Character Select to Avoid Verification” as you like (on by default).
3. Grind as usual. Verification is handled automatically when it appears.
4. Check the records and success rate on the Control Center's “Captcha” page.

## Settings explained

| Setting | What it does |
| --- | --- |
| Return to Character Select to Avoid Verification (Helper menu › General Config) | On by default. When a verification appears, it briefly goes back to character select to avoid it. |
| Captcha Records | Time, character name, image, answer, return time and result. |
| Clear Records (right-click) | Clears every record. This cannot be undone. |

## Good to know

- The final result is whatever the game says. “Pending” means it is still waiting for the game to confirm.
- Hover over an account in the Control Center to see how many captchas it has handled.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
