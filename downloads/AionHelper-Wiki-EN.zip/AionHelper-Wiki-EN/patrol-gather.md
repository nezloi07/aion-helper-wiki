Want your character to gather in just one area? Turn on “Patrol Gather”, walk to the spots you want in the game and add them one by one. Your character then gathers back and forth along that route.

## Where to find it

1. F10 Helper menu
2. Auto Gather
3. Patrol Gather

## What it does

- Each map saves its own route, so switching maps does not affect the others
- Add your current position as a point in one click
- Reorder, delete or clear points at any time
- Keep your character in an area with lots of resources and few players

## How to use it

1. Tick “Enable patrol gather”.
2. Walk to the first spot and click “Add Current Pos”, then add the other spots in order.
3. Use “Move Up” and “Move Down” to reorder, and select any extra points and click “Delete Selected”.
4. Click “Start Gathering”. Your character moves along the route and gathers your targets on the way.

## Settings explained

| Setting | What it does |
| --- | --- |
| Enable patrol gather | Off by default. When on, the list of points for the current map appears. |
| Add Current Pos | Adds your character's current position to the route. |
| Delete Selected / Clear All | Delete one point, or clear this map's route. |
| Move Up / Move Down | Change the order of the points. |

## Good to know

- Patrol gathering only works on non-Abyss maps.
- Do not place points too far apart. A route that covers an area with many gathering spots works best.
- You cannot add points before the map has finished loading. Wait a moment and try again.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
