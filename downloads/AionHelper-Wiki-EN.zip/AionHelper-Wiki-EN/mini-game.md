Leave the hourly Shugo Festival to the Control Center: when your character has an entry key, it enters automatically, claims the reward when done, then goes back to what it was doing.

- All-in-One card only

## Where to find it

1. Control Center
2. ⚙ Settings
3. Shugo Festival

## What it does

- Enters the Shugo Festival automatically on the hour
- Plays through, claims the reward, and extracts low-value gear before leaving
- Usually beats most players and earns plenty of rewards
- You can choose “Stay AFK in Shugo Festival” to stay out of the competition
- Goes back to its previous grinding when it ends

## How to use it

1. Make sure you are using the All-in-One card. The settings page shows whether you currently have access.
2. Open Control Center › Settings › Shugo Festival and tick “Automatically enter Shugo Festival” (on by default).
3. Keep the entry key on your character and let it grind on an open field map or in the Abyss.
4. On the hour it enters by itself, and returns when it ends.

## Settings explained

| Setting | What it does |
| --- | --- |
| Automatically enter Shugo Festival | On by default. Enters automatically on the hour. |
| Stay AFK in Shugo Festival | Stays idle once inside without competing. If everyone stays idle, everyone earns more. |

## Good to know

- Your character must have the entry key.
- It joins automatically while you farm on an open field map or in the Abyss.
- This feature is only available with the All-in-One card.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
