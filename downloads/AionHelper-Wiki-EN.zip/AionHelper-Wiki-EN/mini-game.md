# Aion 2 Shugo Festival auto join: enters on the hour, claims rewards
## Related features
[↝ **Daily Activities planner** Arrange quests, Kinah farming, gathering and character switching into a workflow that rotates accounts.](daily-activities.md) [✧ **Free Appearance (All-Purpose Card)** Change your outfit, weapon and wings with a click, and shuffle each one from the favorites you check.](closet.md)

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://goo.su/4P1Ld) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
