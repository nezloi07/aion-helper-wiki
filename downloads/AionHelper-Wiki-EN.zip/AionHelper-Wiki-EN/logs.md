Want to know what happened while you were away? The Control Center's “Daily Records” collects how the workflow ran for every account, and you can right-click an account to see its run log and daily log.

## Where to find it

1. Control Center
2. Daily Records

## What it does

- A global record of the daily workflow: work, gathering, auto combat, character switching and wrap-up
- Browse by date, refreshed automatically every 5 seconds, showing up to 1000 entries
- Export to a txt file
- Right-click an account › View Logs: run log and daily log
- Filter logs by Info, Warning, Error and Debug

## How to use it

1. Click “Daily Records” on the left and pick a date.
2. Click the export button to save a copy.
3. To look at one account, right-click it on the Accounts page › View Logs › view the run log or the daily log.

## Settings explained

| Setting | What it does |
| --- | --- |
| Date / Refresh / export | Pick the date to look at, refresh by hand, or export to a txt file. |
| Auto Scroll | The log window scrolls to the newest line on its own. |
| Info / Warning / Error / Debug | Filter logs by level. |
| Clear Logs | Clears the logs in the current window. |

## Good to know

- Times in Daily Records are shown in Beijing time.
- Attach your logs when you report a problem to support. It makes the cause much easier to find. The feedback channel is Discord (t.me/aionOnl).

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
