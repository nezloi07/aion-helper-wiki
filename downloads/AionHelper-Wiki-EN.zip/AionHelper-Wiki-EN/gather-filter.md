Do not want to gather everything? “Target Filter” decides what is collected, the quality filter skips low-quality nodes, and if you tick Hidden Cube, the helper also checks its spawn spots along the way.

- Quality filter: All-in-One card

## Where to find it

1. F10 Helper menu
2. Auto Gather
3. Target Filter / Gather Options

## What it does

- Tick targets to gather only those items, and right-click to remove targets you do not need
- Add new targets in one click from “Nearby Gatherable Objects”
- Quality filter: gather only white, green or blue-and-above nodes
- Odyle can be set to never be filtered
- Hidden Cube: checks nearby spawn spots on the way and opens it if you have the key. If it is the only thing ticked, the helper visits its spawn spots in turn

## How to use it

1. Open “Auto Gather › Target Filter” and tick the items you need. If one is not in the list, click “Add” under “Nearby Gatherable Objects”.
2. To look for Hidden Cube, tick it among your targets.
3. With the All-in-One card, tick “Enable Quality Filter” and drag “Filter Limit” to white, green or blue.
4. Click “Start Gathering”.

## Settings explained

| Setting | What it does |
| --- | --- |
| Target Filter | Only ticked items are gathered. When the list is empty, everything is gathered. |
| Reset Default / Clear All | Restore the recommended target list, or empty it. |
| Enable Quality Filter | Skips nodes below the quality you set. All-in-One card only. |
| Filter Limit | White / Green / Blue. |
| Do not filter Odyle | On by default. Odyle is not affected by the quality filter. |

## Good to know

- A Hidden Cube spawn spot you have already visited is not revisited for a while, and the search on the way has a time limit so it never holds up normal gathering.
- If you have no key, it skips the cube and comes back later.
- Abyss maps need no targets. The helper gathers smartly on its own.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
