# Aion 2 auto gathering bot: finds nodes, paths to them, fights back

Click “Start Gathering” on the “Auto Gather” tab. The helper finds gatherable objects nearby, walks over to collect them, and fights back when monsters attack. You can gather only what you want, or everything.

## Where to find it

1. F10 Helper menu
2. Auto Gather
3. Start Gathering
Hotkey: Ctrl+G.

## What it does

- Recognizes what can be gathered nearby and paths to it automatically
- Fights back when monsters attack and picks up the loot
- Tick targets to gather only those items. Tick nothing and it gathers everything
- Supports Hidden Cube: tick it and the helper checks nearby spawn spots on the way and opens it if you have the key
- Set a patrol route to gather back and forth along it
- Can enter the Abyss to gather, collecting feathers as it goes
- Looks after flight energy and potions, and uses a return scroll to get unstuck

## How to use it

1. Go to the map you want to gather on and press F10 to open “Auto Gather”.
2. Tick the items you want under “Target Filter”, or leave it empty to gather everything.
3. Turn on “Auto Counter-Attack”, quality filter or patrol gathering if you need them.
4. Click “Start Gathering” (or press Ctrl+G).

## Settings explained

| Setting | What it does |
|---|---|
| Start Gathering / Stop Gathering | Hotkey: Ctrl+G. |
| Auto Counter-Attack | On by default. Fights back when attacked while gathering. |
| Pick Counter-Attack Loot | On by default. Picks up drops after a fight. |
| Target Filter | Only ticked items are gathered. “Reset Default” restores the recommended list, and after “Clear All” everything is gathered. |
| Nearby Gatherable Objects | Lists nearby items with their name, distance and status. Click “Add” to make one a target, or “Go To” to walk straight to it. |
| Auto Refresh / Interval (s) | How often the nearby list refreshes, from 0.1 to 5 seconds. You can also click “Refresh” by hand. |

## Good to know

- Urtongheim is a no-gathering zone. If you get close, the helper uses a teleport scroll to leave.
- Auto Gather cannot run at the same time as Auto Combat or Auto Task.
- At max level, both Auto Task and combat grinding can be set to switch to gathering when they finish.
- Which profession to level, how proficiency promotion past 50 works and which materials are worth gathering are covered in the [AION 2 Crafting Guide](/blog/2025/10/20/aion2-unlocking-the-secrets-of-crafting-in-aio-6457/).

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
