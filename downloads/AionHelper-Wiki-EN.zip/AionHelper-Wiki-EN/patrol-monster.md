# Aion 2 grinding patrol points and monster filter: smart route

Patrol points decide where your character moves back and forth to find monsters, and the monster filter decides which monsters to attack. Click “Smart Plan” and the helper finds a spot with lots of monsters nearby and builds the route for you.

## Where to find it

1. F10 Helper menu
2. Auto Combat
3. Patrol Settings / Monster Filter

## What it does

- Smart Plan: finds the nearest dense monster area and builds a back-and-forth patrol route
- Add points by hand and reorder them. Each map saves its own
- On some maps, the first time you use it, patrol points are preset by race and melee/ranged
- Monster filter: only ticked monsters are attacked. An empty list attacks every monster
- The nearby monster list shows name, distance and level, with one-click adding

## How to use it

1. Open “Auto Combat › Patrol Settings” and click “Smart Plan”, or walk to a spot and click “Add Current Pos”.
2. To fight only certain monsters, tick “Enable Filter” and click “Add” in “Nearby Monsters”.
3. Click “Start Combat”. When no monsters are nearby, your character walks to the next patrol point.

## Settings explained

| Setting | What it does |
|---|---|
| Smart Plan | Builds this map's patrol route automatically (it replaces your existing points) and takes the monster filter into account. |
| Add Current Pos / Delete Selected / Clear All / Move Up / Move Down | Edit the patrol route by hand. |
| Enable Filter | Off by default. When on, only monsters in the filter list are attacked. |
| Filter List | Only ticked monsters are attacked. Right-click to remove one, or click “Clear” to remove them all. |
| Nearby Monsters | Refreshes automatically or with “Refresh”. Click “Add” to put one in the filter list. |

## Good to know

- Around three patrol points that are close to each other works well.
- Patrol points and the monster filter are saved per map and only apply to the current map.
- With “Smart Pet Farming” on, pet farming takes over patrol and the monster filter, and these two sections are hidden for now.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
