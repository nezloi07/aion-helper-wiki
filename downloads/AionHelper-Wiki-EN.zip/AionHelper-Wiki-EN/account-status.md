The Control Center checks every account's status in the background: normal, banned, captcha needed, restricted or session expired. For a banned account, open its details to see the reason and time left, and use “Assist Unban” to open the official unban page.

## Where to find it

1. Control Center
2. Accounts
3. Double-click an account

## What it does

- Account status: Normal, Banned, Captcha, Restricted, Session Expired and more
- Running status: logging in, starting, in game, Queued, Resting, restarting and more, along with whether it is in combat, gathering, on Auto Task or in a dungeon
- Auction access time left, and the account name turns red when it is about to expire
- The details page shows the ban reason, length, time left and unban time
- Assist Unban: opens the official unban page, clicks verify and fills in the email for you
- Restarts the game after a crash and resumes the work it was doing

## How to use it

1. In the account list, look at the “Account Status” and “Running Status” columns.
2. Double-click an account and go to its account and running info.
3. If an account is banned, click “Assist Unban” and complete the image captcha by hand when the page asks.
4. The Control Center rechecks the ban every 10 seconds and updates once the account is unbanned.

## Settings explained

| Setting | What it does |
| --- | --- |
| Account Status | Checked automatically in the background. Nothing to do. |
| Assist Unban | Opens the official unban page and fills it in. You have to complete the image captcha yourself. |
| Bound characters › refresh list / sync current server | Updates each character's level, combat power, Kinah, daily Kinah cap progress and gathering time. |

## Good to know

- The official unban page allows at most 8 attempts per day from the same network.
- A banned account's whole row turns grey, so you can spot it at a glance.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
