# Aion 2 in-game helper menu: press F10, Ctrl hotkeys to start/stop
Once you are in the game, press F10 to open the “Aion Helper”. Auto quests, gathering, combat, dungeons, free appearance and general settings all live in this window, one tab for each kind of feature.

## Where to find it
1. Enter the game
2. Press F10
3. Aion Helper
The window title shows your remaining card time, how long it has been running and what it is doing. The tab that is currently running turns green.

## What it does
* Six tabs: Auto Task, Auto Gather, Auto Combat, Auto Dungeon, Free Appearance (All-in-One card) and General Config
* Every tab has a start/stop button at the top, with its hotkey shown next to it
* Switch the menu language between Simplified Chinese, English and Korean instantly
* If a feature is temporarily unavailable after a game update, the menu lists it and retries automatically

## How to use it
1. Once your character is in the game, press F10. The menu appears in the top-left corner and can be dragged anywhere.
2. Switch to the tab you want and adjust the settings as needed.
3. Click the start button at the top of the tab, or just press its hotkey.
4. Press the hotkey again or click the stop button to finish. F10 hides the menu at any time.

## Settings explained

| Setting | What it does |
| --- | --- |
| F10 | Show or hide the helper menu. |
| Ctrl+T | Start or stop Auto Task. |
| Ctrl+G | Start or stop Auto Gather. |
| Ctrl+B | Start or stop Auto Combat. |
| Ctrl+D | Start or stop Auto Dungeon. |
| General Config › Language 语言 언어 | Change the menu language. It takes effect immediately. |

## Good to know
* Auto Task, Auto Gather and Auto Combat can only run one at a time. Starting one stops the other two.
* If you see “Update required”, close the game, run the Updater, then go back in.
* Inside Krao Cave, the gathering and combat tabs are hidden for now, so only Auto Task or Auto Dungeon can be used.

## Related features
[🔑 **Updater and card key login** Install the helper, log in your card key, and re-run after every game update.](updater.md) [📋 **Auto Task** Runs the main story from level 0 to 45, then clears side quests and explores caves.](auto-quest.md) [⛏ **Auto Gather** Finds gathering spots, walks to them and fights back when attacked.](gathering.md) [⚔ **Auto Combat** Skill rotation

...

Download Aion Helper and follow the steps above to get started.
[Download Now](https://goo.su/4P1Ld) [Setup checklist & crash fixes →](setup.md)
Aion Helper

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://goo.su/4P1Ld) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
