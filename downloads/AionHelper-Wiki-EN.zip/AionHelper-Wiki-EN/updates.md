# Latest Updates

Stay up to date with the latest features, fixes, and improvements to Aion Helper.

---

## Oct 17–23, 2026: Full dungeon automation, Abyss entry, daily activities

**Major features:**
- **Krao Cave full automation** (19 Oct): Team matchmaking with guaranteed tank + healer. Requires 60K power (threshold briefly changed to 55K on 23 Oct, reverted at 21:02).
- **Normal Dragon dungeon** (23 Oct): Automatic gear prep — characters below Krao threshold farm Normal Dragon for defense gear first.
- **Daily activities expanded** (22 Oct): Added **Daily dungeons** (enhancement stones), **Daily nightmare** (Guardian points & engraving skill points), **Awakening war**.
- **All-in-one card Abyss automation** (22 Oct): Auto-enter Abyss, auto-use Abyss stones (fast-expiring first, no overflow).

**Combat improvements:**
- **Boss dodge mechanics** (17 Oct): New dodge pattern for Boss skills. Integrated into Krao Cave on 18 Oct; melee classes dodge when low HP (23 Oct).
- **Tail king fixes** (23 Oct): Corrected wave attack range (+1m from model scale fix), no green orb collection during final phase (22:41 version), auto-revive after wave ends.
- **Skill cycle optimization** (23 Oct, 22:41): Higher attack frequency, improved rotation logic across all classes.

**Progression path (fully automatic):**
1. Main story + side quests → level 45
2. Daily activities (dungeons, nightmare, awakening) → gear-level boost
3. Normal Dragon → defense gear (if below 60K power)
4. Krao Cave → weapons + materials (60K+ power)
5. Abyss → feathers + Empyrean Traces (All-in-one card)

**Control Center:**
- **One IP per account binding** (22 Oct): Persistent IP routing for ban prevention. Third-party IP tools incompatible — must use self-hosted IPs.
- **Unified character scheduling** (22 Oct): Control Center manages all character switching. In-game auto-switch removed.
- **8 continuous character launch** (22 Oct): Fixed manual slot expansion issue — all 8 character slots auto-create.
- **Account on/off toggle** (19 Oct): Pause Control Center to play manually.

**Character management:**
- **Auto-enhancement by power** (23 Oct): Enhancement & equip logic switched from gear-level to power rating. Default threshold 60K; AI manages enhancement until threshold reached. New rule: only enhance after dungeon runs (one-click 72K power possible).
- **45-level Guardian points** (22 Oct): Auto-allocate Guardian points added in 21 Oct game update. Each class has priority template.
- **Job templates updated** (18 Oct): New Guardian / skill / engraving templates for all 8 classes. Manual reset required for existing characters (2–3× damage boost claimed).
- **Wings auto-equipped** (23 Oct): Auto-use and equip wings after final awakening quest.
- **Festival token conversion** (23 Oct): Auto-convert to Guardian points.

**Daily automation:**
- **Enhancement stone distribution** (23 Oct): Daily dungeons only run when enhancement stones needed — prevents hoarding on single character.
- **Nightmare boss auto-selection** (22 Oct): Control Center picks appropriate boss per character. Reward priority: Guardian points → Engraving skill points.

**Dungeon matchmaking (Krao Cave):**
- Room host ensures: ≥1 tank, ≥1 healer (except when 2+ Dpsellor stars present)
- Fast-join enabled by default (join existing rooms 60K+); auto-create room if none found
- Room bumped every 61s after creation
- Queue requirements: 60K power (3 min → 55K, 6 min → 50K). Healer threshold fixed 50K. Gear-level ≥1200 = 60K equivalent.
- Pre-queue: claim 14× extra reward, go to configured Kinah-farm location, auto-disengage when team ready
- Characters with maxed daily Kinah skip dungeon queue

**Bug fixes & tweaks:**
- **Auto-quest abandonment** (17 Oct): Abandon after 10 deaths (same cave) / 15 deaths (same branch) — no infinite death loops.
- **Auction threshold lowered** (19 Oct): Blue refined stone 10×, green 20×. Spirit stones excluded from auto-post (22 Oct).
- **Gathering filter** (21 Oct): Removed wild gather filter, kept Abyss filter. International server quality filter restored (All-in-one feature).
- **Guardian captcha** (19 Oct, 21 Oct, 23 Oct): Auto-logout after 8 consecutive captcha fails or connection timeout. Fixed HK server auth issue (21 Oct).
- **Ore energy backpack** (23 Oct): Optimized inventory check — no premature dungeon exit.
- **Updater** (17 Oct, 22 Oct): Fixed fallback route issue; two forced updates on 22 Oct evening.

**Card status:**
Free trial ended early (22 Oct) due to overload. **Auto-dungeon & Abyss features now require All-in-one monthly card.**

**Update instructions:**
Open the Updater to auto-update. **Recommended:** Test with 1–3 accounts first due to frequent rule changes this week. Monitor Normal Dragon / Krao Cave performance per class before mass-enable.

**Daily build logs:** See official updates Oct [17](https://www.aion.onl/blog/2026/10/17/), [18](https://www.aion.onl/blog/2026/10/18/), [19](https://www.aion.onl/blog/2026/10/19/), [20](https://www.aion.onl/blog/2026/10/20/), [21](https://www.aion.onl/blog/2026/10/21/), [22](https://www.aion.onl/blog/2026/10/22/), and Oct 23 (16:48, 21:02, 22:41 UTC).

---

**Questions or issues?** Contact **U.Tools** in the [U.Community Discord](https://discord.gg/yYbzkcqsp2).

[← Back to Home](Home.md)
