Tick “Auto Enter Abyss” under “Auto Combat › Abyss Settings”. When the layer you chose has enough time left, the helper enters the Abyss, grinds monsters along your patrol points, and can attack enemy players if you want.

## Where to find it

1. F10 Helper menu
2. Auto Combat
3. Abyss Settings

## What it does

- Enters automatically when the chosen layer has more than 10 minutes left, and skips this if you are already in the Abyss
- Choose the lower or middle layer
- Attack Enemy Players: attacks the nearest enemy player within 25 meters
- Works together with patrol points and Smart Plan for grinding
- Uses Abyss Stones automatically to top up your time
- Golden gear from the Abyss can be left to the Auction House's automatic listing

## How to use it

1. Press F10 to open “Auto Combat” and tick “Auto Enter Abyss” under “Abyss Settings”.
2. Choose the “Target layer”: lower or middle.
3. Tick “Attack Enemy Players” if you want PvP.
4. Set up your patrol points, then click “Start Combat”.

## Settings explained

| Setting | What it does |
| --- | --- |
| Auto Enter Abyss | Off by default. Enters automatically when the chosen layer has more than 10 minutes left. |
| Target layer | Lower (default) / Middle. |
| Attack Enemy Players | Off by default. When on, attacks the nearest enemy player within 25 meters in the Abyss. |

## Good to know

- Returns vary with your combat power, market prices and how the run goes.
- To gather in the Abyss, see “Abyss gathering and feathers”.
- Combined with “Auto auction listing”, golden gear from the Abyss can be sold automatically.
- Abyss PvP itself stays manual. Where to fight and which PvP stats to stack: AION 2 PvP guide.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
