The Control Center (Aion Helper Control Center) is the desktop tool for managing many accounts. Add your accounts, then log them into the game in batches, start daily activities with one click, and see every account's status, Kinah and latest message in a single table.

- Taiwan · Korea · Global

## Where to find it

1. Updater
2. Start Control Center
3. Accounts

The icon bar on the left shows, from top to bottom: Accounts, Captcha, Daily Records and Feedback. The ⚙ at the bottom opens Settings.

## What it does

- Add an NC email account, or sign in through Google, Steam, Apple and other platforms. The server is detected automatically
- Select several accounts and start or stop them in one go
- Click “Start Daily Activities” and every enabled account follows the workflow you arranged
- The account list shows running status, account status, Auction access left, Kinah and work/rest countdowns
- Double-click an account to see its characters: level, combat power, Kinah, daily Kinah cap progress and gathering time
- Right-click an account to pin it, start combat or gathering, edit the character config, view logs, edit or delete

## How to use it

1. Click “Start Control Center” in the Updater.
2. Click “Add Account” and choose “NC Email Account” or a platform. For an email account, enter the email and password, click “Verify”, then “Save”. Global accounts also need a region.
3. Go to “Settings › General” to check the game path and game language.
4. Turn on the account's Status switch, select the accounts and click “Start Selected Accounts”, or just click “Start Daily Activities”.
5. Watch progress in the list, and double-click an account for details.

## Settings explained

| Setting | What it does |
| --- | --- |
| Add Account | Supports NC email accounts and platform accounts (Google, Facebook, Apple, Twitter, LINE, Steam, VK and more). Platform accounts sign in through a pop-up browser, and your password is not saved. |
| Global server region | North America - East, North America - West, Europe, South America or Asia. |
| Status switch | Decides whether this account takes part in batch starts and daily activities. |
| Start Daily Activities | Every enabled account runs the workflow in “Settings › Daily Activities”. Click again to stop. |
| Start Selected Accounts / Stop Selected | Hold Shift or Ctrl to select several accounts, then log them in or close their games in one go. |
| Right-click › Character Config | Save the current character's settings as the default config, or apply them to your other online characters in one click. |
| Right-click the table header | Show or hide columns such as server, account status, Kinah and latest message. Column widths are remembered. |
| Note | Add a note to an account. Hover over the account to read it. |

## Good to know

- Windows 10 is recommended.
- If you use a network accelerator, add the Control Center to its accelerated list too, or logins may fail.
- Multi-account launching uses the game client downloaded through the Purple platform. Steam accounts can be added too and log in through Purple.
- If you only run one game, you can skip the Control Center and press F10 in the game to use the helper.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
