# Aion 2 auto flight and supplies: flight potions, return scrolls
There is nothing to set up here. Auto Task and Auto Gather decide when to take off and whether your flight energy is enough, drink flight potions when energy is low, and use a return scroll to get unstuck.

...

## What it does
* Improves takeoff timing during quests and gathering
* Uses a flight potion automatically when flight energy drops below 15%
* Recognizes the flight potions in your inventory
* Restocks potions automatically when needed
* Uses a return scroll automatically when stuck

...

## Related features
[📋 **Auto Task** Runs the main story from level 0 to 45, then clears side quests and explores caves.](auto-quest.md) [⛏ **Auto Gather** Finds gathering spots, walks to them and fights back when attacked.](gathering.md)

...

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
