In the Control Center, arrange Auto Task, Kinah farming, gathering and character switching into one workflow. Every enabled account runs it through each character in order, then wraps up the way you set.

## Where to find it

1. Control Center
2. ⚙ Settings
3. Daily Activities

## What it does

- Build your workflow like blocks: gathering, Kinah farming, Auto Task and Switch character
- Drag steps to reorder them, copy or delete them, and add the same step more than once
- Built-in templates: Default (Auto Task → Kinah farming → Switch character), Kinah farming + gathering, gathering across characters, and Auto Task + Kinah farming + gathering
- Each day Kinah farming stops at a random 93%–99% of the daily Kinah cap
- After all characters are done: close the game, or keep gathering on the last character until the server's daily reset
- Import and export your settings, so several computers can share the same workflow

## How to use it

1. Open Control Center › Settings › Daily Activities.
2. Click a template to get started, or build your own with “+ Gathering”, “+ Kina farming”, “+ Auto quest” and “+ Switch character”.
3. Select a step to adjust its settings (for example the gathering time), then click “Apply instruction settings”.
4. Choose what happens under “After all characters finish”, then save.
5. Go back to the Accounts page and click “Start Daily Activities”, or click “Start daily workflow” on this page.

## Settings explained

| Setting | What it does |
| --- | --- |
| + Gathering | Gathers for a while. You can set a minimum and maximum number of minutes, and each run picks a random time. |
| + Kina farming | Fights monsters to earn Kinah, stopping each day at a random 93%–99% of the cap. You can tick “Plan patrol route before combat”. |
| + Auto quest | Runs quests and daily quests. |
| + Switch character | Switches to the next character. It must be the last step, and there can be only one. |
| Reset timer | Picks a new random gathering time each time gathering comes around. When on, characters keep rotating in a loop. |
| After all characters finish | Close the game, or start gathering. |
| Start daily workflow / Pause all / Resume all / Stop all | Control every enabled account at once. |
| Import settings / Export settings / Open settings folder | Back up or share your workflow. |

## Good to know

- The “Switch character” step must come last.
- The “Daily Records” page shows how the workflow went for each account.
- To control how many accounts are online and when they log on and off, use it together with “Work Schedule”.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
