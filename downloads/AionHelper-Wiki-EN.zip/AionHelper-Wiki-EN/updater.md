The Updater (Aion2.Updater) installs the in-game helper, logs in your card key and checks for updates. Start here the first time, when you change your card key, and after every game update.

- All card types
- Taiwan · Korea · Global · Steam

## Where to find it

1. Download Aion Helper
2. Run Aion2.Updater.exe

The ⚙ menu in the top-right corner has “Install Runtime”, “Change card key” and “Uninstall”. The 🌐 button switches between Simplified Chinese, English and Korean.

## What it does

- Log in with your card key; once it is verified, the in-game helper is installed or updated automatically
- Finds your Taiwan, Korea, Global and Steam game folders on its own
- Shows the latest announcement when it opens, and you can choose not to see it again
- Click “Start Control Center” as soon as the install finishes
- Install the runtime in one click if the game misbehaves, or uninstall in one click when you no longer need the helper

## How to use it

1. Download the package from the website's download page, unzip it and run Aion2.Updater.exe.
2. Enter your key in “CARD NUMBER” and click “LOGIN”. New users can click “Get free trial card” first to get a free 3-hour test card.
3. Wait for the progress bar to finish. When you see “Components installed successfully”, you are done.
4. With several accounts, click “Start Control Center”. With a single game, just launch the game and press F10 to open the helper menu.

## Settings explained

| Setting | What it does |
| --- | --- |
| CARD NUMBER / LOGIN | Enter your card key and verify it. It is saved, so the Updater logs you in automatically next time. |
| Change card key (⚙ menu) | Switch to a new card. Your current authorization stays in place until the new card is verified. |
| Install Runtime (⚙ menu) | Installs the system components the helper needs. Try this first if the game crashes or the helper will not open. |
| Uninstall (⚙ menu) | Removes the helper from every game folder it found. |
| Retry update | Appears when an update fails. Click it to download again. |
| Language (🌐) | The Updater's display language: Simplified Chinese, English or Korean. |

## Good to know

- Re-run the Updater after every game update. Otherwise the helper shows “Update required” and will not work for the moment.
- If the game folder cannot be found, install the game and launch it at least once, or select Aion2.exe by hand when prompted.
- Your card key must cover the server you play on. For example, playing on Korea needs a card that supports Korea.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
