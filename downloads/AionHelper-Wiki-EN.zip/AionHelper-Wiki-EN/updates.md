# Latest Updates

Stay up to date with the latest features, fixes, and improvements to Aion Helper.

---

## Oct 31, 2026 (17:29 UTC+8): Extraction and destruction skip crafted gear

- Extraction and destruction now skip hand-crafted equipment. Player-crafted pieces are no longer selected for extraction or destruction, so a manually crafted item cannot be lost to the automatic clean-up.

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 30, 2026 (02:48 UTC+8): Control Center changes for the gathering limit

Because gathering is now capped by a daily count, the Control Center behaves differently:

- "Start gathering" after daily activities removed for all characters. On finish the helper always closes the game and puts the account into rest until it resumes the next day.

- Character-rotation gathering template reworked.

- "Switch to next character" is now optional. The instruction can be deleted — with no such instruction the game is closed once the tasks are complete.

- Dungeon timeout: 20 minutes. A normal party clears in 7–10 minutes, so the character now leaves the dungeon by itself after 20 minutes — whether the party wiped or is still waiting for members to gather.

- Official subscription IP: if the assigned IP temporarily fails, a nearby working IP is reassigned automatically.

Update: open the Updater, it pulls the latest build automatically.

---

## Build 16.1 (Global): gathering limit, Hidden Cubes only

- Gathering limit: gathering now stops after 1000 gathers by default.

- New preference — Hidden Cubes only: the character gathers only the key-opened hidden backpacks. Requirement: the gather item ID set in your gathering settings must be the hidden backpack's ID.

Latest EXE version: 16.1. Update: open the Updater, it pulls v16.1 automatically.

---

## Oct 29, 2026 (12:57 UTC+8): Hotfix

- Control Center: fixed a bug where, after gathering was completed, the Control Center failed to put the account on rest and switch to the next account.

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 28, 2026 (22:46 UTC+8): Hotfix

- Belts and amulets — auto-upgrade now stops at gold grade.

- Awakening War (Global) — progression blocker fixed.

- Korea server — fixed a crash caused by auto-task and gathering running together.

Update: open the Updater, it pulls the latest build automatically.

---

## Build 15.1 (Global): Steam processes, Asmodian level 44 quest

- Synced with the game update.

- Steam: fixed the "too many phantom Steam processes" issue.

- Asmodian level 44 quest: fixed a progression blocker.

Latest EXE version: 15.1. Update: open the Updater, it pulls v15.1 automatically.

---

## Oct 28, 2026 (19:00 UTC+8): Server update support

- Today's Global server update supported. Korea, Taiwan and Global are all updated — every region runs the current game build.

- Awakening War — this week's rotation applied.

- Skill casting optimized for all classes.

- Gathering stops automatically once the daily gathering count limit is reached.

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 27, 2026 (11:39 UTC+8): Stigma check, godstone socketing, Soul Imprint

- Stigma interrupt check — Krao Cave only. The loadout is verified only when queuing for Krao Cave, and for both the host and the party members. If none of the slotted stigmas has an interrupt effect, all stigmas are force-reset and re-learned / re-slotted from the build plan, so an interrupt is guaranteed for the boss. The reset costs nothing and does not affect Specialty. At no other time are stigmas reset.

- Auto godstone socketing. Equipment that is worn, item level 45 or higher, has an empty godstone slot and is not yet socketed gets a godstone from your bag automatically. Priority is what helps most in PvE and against bosses: single-target damage > damage over time (poison, bleed) > area damage > control effects (bosses are largely immune to control). Within the same category, grade decides: Unique > Legendary > Rare. One copy of a given godstone has effect — a stone already worn is not socketed again.

- Auto Soul Imprint upgrade. Worn equipment at item level 54 or higher that has already been soul-imprinted is upgraded automatically while imprint materials are available, up to a sync rate of 100%. The highest item level is finished first, then the next tier. If materials or Kinah run out the process pauses and resumes on its own once they are replenished.

- Order of operations. Manastone socketing, godstone socketing and Soul Imprint upgrades all run after the gear swap — and also in the background when no auto task is running (idling, gathering, dungeons).

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 26, 2026 (17:28 UTC+8): Hotfix

- Draupnir dungeon flow optimized — smoother run progression.

- Control Center fixes — resolved several reported issues.

- Stigma reset loop fixed — if you set stigmas manually, activate the first stigma slot and include at least one interrupt skill — the check runs when queuing Krao Cave (details).

- ⚠ Multi-account users: enable the one account per IP option in Control Center settings to significantly reduce ban risk.

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 25, 2026 (19:48 UTC+8): Optimizations

- Mini-games and Nightmare Store: now exchanges 10 Guardian points first, then 10 stigma skill tokens, cycling between the two.

- Daily Activities work-hour limit: now enforced when daily activities are enabled (previously ignored).

- Draupnir optimization: opening NPC dialogue fixed; the party now waits for all members to arrive before entering the final boss room.

- Stigma skill leveling: all four stigma slots are upgraded to level 5 first, then to level 10. Skills with buffs are prioritized.

- Skill rotation optimization: reduced animation lock / ability queueing delays across all classes.

- Control Center IP service: one account per IP now available. Global IP addresses offered at wholesale pricing.

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 24, 2026 (20:53 UTC+8): Hotfix

- Draupnir (Normal): fixed the stuck point after the first boss; dungeon run optimized.

- Skill rotation: combat cycle optimized.

- Main story: fixed a quest progression stuck point.

Update: open the Updater, it pulls the latest build automatically.

---

## Oct 17–23, 2026: Full dungeon automation, Abyss entry, daily activities

Major features:
- Krao Cave full automation (19 Oct): Team matchmaking with guaranteed tank + healer. Requires 60K power (threshold briefly changed to 55K on 23 Oct, reverted at 21:02).
- Draupnir (Normal) (23 Oct): Automatic gear prep — characters below Krao threshold farm Draupnir (Normal) for defense gear first.
- Daily activities expanded (22 Oct): Added Daily dungeons (enhancement stones), Daily nightmare (Guardian points & engraving skill points), Awakening war.
- All-in-one card Abyss automation (22 Oct): Auto-enter Abyss, auto-use Abyss stones (fast-expiring first, no overflow).

Combat improvements:
- Boss dodge mechanics (17 Oct): New dodge pattern for Boss skills. Integrated into Krao Cave on 18 Oct; melee classes dodge when low HP (23 Oct).
- Tail king fixes (23 Oct): Corrected wave attack range (+1m from model scale fix), no green orb collection during final phase (22:41 version), auto-revive after wave ends.
- Skill cycle optimization (23 Oct, 22:41): Higher attack frequency, improved rotation logic across all classes.

Progression path (fully automatic):
1. Main story + side quests → level 45
2. Daily activities (dungeons, nightmare, awakening) → gear-level boost
3. Draupnir (Normal) → defense gear (if below 60K power)
4. Krao Cave → weapons + materials (60K+ power)
5. Abyss → feathers + Empyrean Traces (All-in-one card)

Control Center:
- One IP per account binding (22 Oct): Persistent IP routing for ban prevention. Third-party IP tools incompatible — must use self-hosted IPs.
- Unified character scheduling (22 Oct): Control Center manages all character switching. In-game auto-switch removed.
- 8 continuous character launch (22 Oct): Fixed manual slot expansion issue — all 8 character slots auto-create.
- Account on/off toggle (19 Oct): Pause Control Center to play manually.

Character management:
- Auto-enhancement by power (23 Oct): Enhancement & equip logic switched from gear-level to power rating. Default threshold 60K; AI manages enhancement until threshold reached. New rule: only enhance after dungeon runs (one-click 72K power possible).
- 45-level Guardian points (22 Oct): Auto-allocate Guardian points added in 21 Oct game update. Each class has priority template.
- Job templates updated (18 Oct): New Guardian / skill / engraving templates for all 8 classes. Manual reset required for existing characters (2–3× damage boost claimed).
- Wings auto-equipped (23 Oct): Auto-use and equip wings after final awakening quest.
- Festival token conversion (23 Oct): Auto-convert to Guardian points.

Daily automation:
- Enhancement stone distribution (23 Oct): Daily dungeons only run when enhancement stones needed — prevents hoarding on single character.
- Nightmare boss auto-selection (22 Oct): Control Center picks appropriate boss per character. Reward priority: Guardian points → Engraving skill points.

Dungeon matchmaking (Krao Cave):
- Room host ensures: ≥1 tank, ≥1 healer (except when 2+ Dpsellor stars present)
- Fast-join enabled by default (join existing rooms 60K+); auto-create room if none found
- Room bumped every 61s after creation
- Queue requirements: 60K power (3 min → 55K, 6 min → 50K). Healer threshold fixed 50K. Gear-level ≥1200 = 60K equivalent.
- Pre-queue: claim 14× extra reward, go to configured Kinah-farm location, auto-disengage when team ready
- Characters with maxed daily Kinah skip dungeon queue

Bug fixes & tweaks:
- Auto-quest abandonment (17 Oct): Abandon after 10 deaths (same cave) / 15 deaths (same branch) — no infinite death loops.
- Auction threshold lowered (19 Oct): Blue refined stone 10×, green 20×. Spirit stones excluded from auto-post (22 Oct).
- Gathering filter (21 Oct): Removed wild gather filter, kept Abyss filter. International server quality filter restored (All-in-one feature).
- Guardian captcha (19 Oct, 21 Oct, 23 Oct): Auto-logout after 8 consecutive captcha fails or connection timeout. Fixed HK server auth issue (21 Oct).
- Ore energy backpack (23 Oct): Optimized inventory check — no premature dungeon exit.
- Updater (17 Oct, 22 Oct): Fixed fallback route issue; two forced updates on 22 Oct evening.

Card status:
Free trial ended early (22 Oct) due to overload. Auto-dungeon & Abyss features now require All-in-one monthly card.

Update instructions:
Open the Updater to auto-update. Recommended: Test with 1–3 accounts first due to frequent rule changes this week. Monitor Draupnir (Normal) / Krao Cave performance per class before mass-enable.

Daily build logs: See official updates Oct 17, 18, 19, 20, 21, 22, and Oct 23 (16:48, 21:02, 22:41 UTC).

---

Questions or issues? Contact U.Tools in the U.Community Discord.

← Back to Home