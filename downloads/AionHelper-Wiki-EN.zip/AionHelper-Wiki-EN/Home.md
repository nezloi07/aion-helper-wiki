# Aion Helper — AION 2 Automation Wiki

The complete guide to Aion Helper for AION 2: quest leveling 0–45, auto gathering, auto combat, Abyss farming, dungeons, market listings and multi-account Control Center. Works on Steam Global, Korea (KR) and Taiwan (TW) servers, for both Elyos and Asmodians.

> 🛒 **Buy a card key:** [unicom.market — Aion 2 Software](https://unicom.market/product/aion-2-software-hlp/) ·
> 💬 **Support & updates:** [U.Community Discord](https://discord.gg/yYbzkcqsp2) · 🛠 **For problems, contact U.Tools** ·
> 🎬 **Video guide (first launch + feature overview):** [watch on YouTube](https://www.youtube.com/watch?v=TTUGEMEy2bE)
>
> 🎬 **How to launch the bot on the Steam version:** [watch on YouTube](https://youtu.be/-phYoqnVgA4)
>
> ⬇️ **Client download:** [Aion2.Updater.zip](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea)

## 🚀 Quick start

1. **Download** `Aion2.Updater.zip` and extract it to its own folder. Don't run it from inside the archive.
2. **Choose your game resolution before running the updater** — it can't be changed after installation. Windowed and fullscreen both work.
3. **Run `Aion2.Updater.exe`** and log in with your card key (“CARD NUMBER” → “LOGIN”). New users can claim a free 3-hour trial card. Buy cards on [unicom.market](https://unicom.market/product/aion-2-software-hlp/).
4. **Launch AION 2** and enter your character. The Aion Helper window opens automatically; press **F10** if it doesn't. Turn on the features you need.

System requirements: Windows 10/11 (64-bit), VC++ runtime libraries (install them with one click in the updater's ⚙ menu). If the game crashes on start, see [Setup checklist & crash fixes](setup.md).

After every game update run the updater again, otherwise the helper shows “Update required” and stays off until you do.

## 🧩 Multi-client with VK Multi

**Multi-accounting works when Aion Helper is used together with VK Multi.** Be ready for it: VK Multi is genuinely demanding on your system, and **all Windows protections must be truly disabled** — Windows Defender / antivirus real-time protection, SmartScreen and related security features. A half-disabled setup (e.g. Defender only silenced by settings that turn back on) will not run it properly.

See it in action on the live wiki (screenshot of two clients + Control Center + VK Multi) and get it on [unicom.market](https://unicom.market/).

## ⌨ Hotkeys

| Key | What it does |
| --- | --- |
| F10 | Show / hide the Aion Helper window |
| Ctrl+T | Auto quests: start / stop |
| Ctrl+G | Auto gathering: start / stop |
| Ctrl+B | Auto combat: start / stop |
| Ctrl+D | Auto dungeon: start / stop |

Auto quests, auto gathering and auto combat can't run at the same time — starting one stops the other two. Details: [Helper menu & hotkeys](helper-menu.md).

## 📂 Wiki sections

### 1. Getting started

| Page | What's inside |
| --- | --- |
| [Updater & card key login](updater.md) | Install, change card key, “Install Runtime”, uninstall |
| [Setup checklist & crash fixes](setup.md) | Resolution first; two fixes against crashes |
| [Helper menu & hotkeys](helper-menu.md) | F10, six tabs, Ctrl shortcuts |
| [Control Center (multi-account)](control-center.md) | Add accounts, batch login, one status table |
| [Servers & game paths](servers.md) | Taiwan · Korea · Global · Steam; path and language |

### 2. Auto tasks

| Page | What's inside |
| --- | --- |
| [Auto quests · level 0–45](auto-quest.md) | Main story quests to 45, then valuable side quests, both races, all classes |
| [Daily quests](daily-quests.md) | One tick — dailies finish before side quests |
| [Reward caves](caves.md) | Guardian points and skill points from caves after side quests |

### 3. Auto gathering

| Page | What's inside |
| --- | --- |
| [Auto gathering](gathering.md) | Finds gather nodes, walks to them, fights back |
| [Gather filter & Hidden Cubes](gather-filter.md) | Target materials, quality filter, Hidden Cubes |
| [Patrol gathering](patrol-gather.md) | Custom route in a resource-rich area |
| [Abyss gathering & feathers](abyss-gathering.md) | Auto-enter the Abyss; unfinished feathers first |

### 4. Auto combat

| Page | What's inside |
| --- | --- |
| [Auto combat](auto-combat.md) | Skill rotations for every class; pull-in and fast shot optional |
| [Patrol & monster filter](patrol-monster.md) | One-click patrol route, only marked mobs get killed |
| [Pet & mount farming](pet-farming.md) | Smart point switching once taming cap is reached |
| [Abyss farming](abyss-farming.md) | Auto-enter, tier selection, optional PvP |

### 5. Dungeon · Appearance · General

| Page | What's inside |
| --- | --- |
| [Auto dungeons (beta)](dungeon.md) | Krao Cave runs automatically; free for everyone during beta |
| [Free appearance](closet.md) | Outfits, weapons and wings in one click (universal card) |
| [Auto auction listing](auction.md) | Golden gear and materials hit the market with auto pricing |
| [Guardian captcha · AI recognition](captcha.md) | Built-in AI solves the Guardian verification, free, no ClientKey |
| [Flight & energy](flight.md) | Takeoff timing, flight potions, scroll of recall — all automatic |

### 6. Control Center · multiple accounts

| Page | What's inside |
| --- | --- |
| [Daily activities planner](daily-activities.md) | Quests, Kinah farming, gathering and character switching in one plan |
| [Work schedule & queue](work-schedule.md) | Online account limits, randomized work/rest cycles |
| [Shugo Festival (hourly mini-game)](mini-game.md) | Joins the hourly mini-game, grabs rewards, returns to farming |
| [Account status & recovery](account-status.md) | Ban checks, crash restart, resume |
| [Activity logs](logs.md) | Per-day activity records and per-account logs |

### 7. Questions & support

* [FAQ — safety, setup, pricing, multi-client, support](FAQ.md)
* [Support FAQ — real chat reports: updates/auth, combat, dungeons, risk](support-faq.md)

---

**Useful links**

* Buy a card key: [unicom.market](https://unicom.market/product/aion-2-software-hlp/)
* Community, support and news: [discord.gg/yYbzkcqsp2 — 🔷U.Community🔶](https://discord.gg/yYbzkcqsp2)
* Download the client: [Aion2.Updater.zip — direct download](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea)
