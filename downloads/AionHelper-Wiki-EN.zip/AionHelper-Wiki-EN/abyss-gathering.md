# Aion 2 Abyss auto gathering: enters the Abyss, collects feathers

Tick “Automatically enter Abyss for gathering” and the helper goes into the Abyss to gather by itself. Inside, you can also turn on feather collection so it heads for feathers you have not collected yet first.

- Auto enter Abyss: All-in-One card

## Where to find it

1. F10 Helper menu
2. Auto Gather
3. Gather Options

## What it does

- Enters the Abyss to gather automatically, with no manual teleport
- Gathers smartly in the Abyss, with no targets to set
- Collect feathers: heads for feathers you have not collected yet first
- Stops collecting feathers once your feather progress is enough for level 30
- Each feather has its own timer. If it is not collected within 3 minutes, it is skipped, so the helper never gets stuck in one place

## How to use it

1. Open “Auto Gather › Gather Options” and tick “Automatically enter Abyss for gathering”.
2. Once you are in the Abyss, make sure “Collect feathers” is ticked (it is on by default).
3. Click “Start Gathering”.

## Settings explained

| Setting | What it does |
|---|---|
| Automatically enter Abyss for gathering | Off by default. All-in-One card only. |
| Collect feathers (roam to uncollected Empyrean Traces) | Only shown in the Abyss. On by default. |

## Good to know

- To grind monsters in the Abyss instead, see “Abyss auto farming”.
- You do not need to, and cannot, set gathering targets in the Abyss. The helper decides for itself.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
