# Aion Helper support FAQ — what the community and vendor actually said

Answers below are based on chat reports and update announcements. They describe what participants or the vendor said; they are not guarantees that a fix will work in every case. "Theory" in parentheses is an explanation, not a confirmed diagnosis.

## Updates, authorization, and connection

### Q: The software fails to update or authorization is rejected. What should I try first?

A: Close Aion Updater completely, reopen it, and run the update again. If the update still fails, try a different connection, such as switching between Wi-Fi and mobile data. VPN or a network accelerator was also suggested in chat, but was not confirmed as a universal fix.

*(Theory: Some update or authorization failures may be caused by incomplete local files or network connectivity.)*

### Q: The updater says I have the latest version, but authorization is still rejected. Is the problem fixed?

A: Not necessarily. A user reported that the updater showed the latest version while authorization continued to fail. Retrying the updater is worth checking, but do not assume the issue is resolved until authorization succeeds.

### Q: The update is unusually slow. What can I check?

A: Check your connection and try another network. Chat participants also suggested a VPN or network accelerator; one user reported better startup speed after changing an accelerator node. That is an individual report, not a guaranteed solution.

*(Theory: Network congestion or routing may affect update speed.)*

### Q: Should I launch the software immediately after game maintenance?

A: The chat recommendation was to wait until the developer confirms that the software is compatible with the post-maintenance game version.

### Q: Authorization or verification takes a long time. Does that always mean it is broken?

A: No. Chat participants suggested that high login or verification traffic may cause delays. One user reported faster startup after changing an accelerator node, but the chat did not establish a standard verification time.

## Automatic combat and Abyss

### Q: My character stands still even though automatic combat and Abyss entry are enabled. What should I check?

A: Check that automatic combat for the Abyss is enabled, that the character has sufficient combat power, and that the daily activity or farming-time limit has not run out. Also check whether an unfinished or incompatible daily task is blocking progress.

*(Theory: Any of these conditions may prevent the activity from starting; the chat does not establish one cause for every case.)*

### Q: Automatic combat starts, but it does not use my custom skill rotation. What should I check?

A: In chat, users were advised to drag the custom skill macro to the right-click hotbar slot. The software is reported to use the macro assigned there. Also confirm that the relevant activity is enabled and that the daily limit has not been exhausted.

### Q: Automatic combat attacks only nearby enemies or seems to have a short range. What should I check?

A: Check the custom macro assigned to the right-click hotbar slot, daily activity settings, patrol points, combat power, and remaining daily activity time. The chat did not contain a confirmed fix for every range-related problem.

### Q: My character does not enter or fight in the Abyss as expected. What setting was mentioned in chat?

A: Participants specifically mentioned enabling automatic combat for the Abyss. The automatic-entry option alone may not be enough; also check the activity-time limit and combat-power requirements.

### Q: A daily task gets stuck on an Abyss objective. What is known?

A: A later update announcement said that Abyss tasks should be excluded from normal daily-task execution. The same announcement mentioned fixes for some task-flow problems after level 45. Check that you have a version containing those fixes. The chat did not provide a confirmed manual recovery procedure for an already-stuck task.

## Daily tasks and characters

### Q: Can the software prioritize certain daily tasks?

A: An update announcement said tasks are selected according to reward priority—for example, Odyle energy was prioritized over pet crystals. It also said the task list refreshes when no suitable task is available.

*(This describes announced software behavior; it may depend on the version.)*

### Q: What happens if the character stays stuck in a dimension or task for too long?

A: An update announcement described an automatic recovery: the software should leave and re-enter if the character remains stuck for too long. If that does not happen, check the software version and task settings. The chat did not provide a verified manual workaround.

### Q: The automated routine creates a new character, but I want it to level an existing one. What should I do?

A: A developer response in chat advised creating the desired character in advance. The response said that this should prevent the software from creating another character and allow it to level the existing one. The chat did not specify every mode or setting this applies to.

### Q: Tasks started behaving incorrectly after switching characters. What should I do?

A: An update announcement said that an issue corrupting task data after character switching had been fixed. First check that you have the version containing that fix. The chat did not describe a confirmed way to restore data that was already affected.

## Automatic dungeons

### Q: How does automatic dungeon matchmaking lower its combat-power requirement?

A: An update announcement described a default requirement of 60K. If no match is found, it lowers to 55K after three minutes and 50K after six minutes. It also said the room is pinned while matchmaking is in progress.

*(These figures come from a specific update announcement and may change in later versions.)*

### Q: Can the software do other activities while waiting for a dungeon group?

A: An update announcement said it can perform configured "floor gold" farming while queued. When the group is ready, it should leave combat and enter the dungeon. If the activity does not run, check that it is enabled in the daily-task settings.

### Q: The character keeps interacting with the teleport point near the final boss while the party has already moved on. What did users report?

A: Several participants complained that the character kept trying to activate the point while mobs interrupted it and the party waited inside. Some suggested skipping that point and moving on, but the chat did not confirm that as an official or universally safe route.

### Q: Starting automatic dungeon mode removed me from a group I had joined. Is there a confirmed fix?

A: A user reported being removed from a self-created group after joining another group and starting automatic dungeon mode in Krao. The chat did not provide a confirmed fix. Record the game and software versions and the steps that led to the issue when reporting it.

### Q: The character is not behaving correctly around the final boss. Is there an update note about this?

A: An update announcement mentioned improvements to dodging the final boss's whirlwind, interrupting its "number 8" ultimate skill, and timing revives so they do not occur during that ultimate. It also mentioned a fix for floor-gold farming during the queue.

*(This is a summary of the announced changes, not a guarantee that every encounter issue is resolved.)*

## CAPTCHA recognition: troubleshooting

### Troubleshooting order

1. **Confirm the Control Center is running.**
   Only the Control Center processes CAPTCHAs. A game client with the in-game helper alone will not solve them.

2. **Accelerate the Control Center, not the game.**
   Route the Control Center through an accelerator. Xunyou (迅游) in routing mode (路由模式) is the setting reported to fix the "digits instead of letters" and "solver connection failed" cases. Accelerating the game client does not help — the traffic that matters belongs to the Control Center.

3. **Check reachability of the Hong Kong, Japan and Singapore nodes.**
   If these are blocked, the CAPTCHA image never reaches the solver and no solution can return.

4. **Increase the game window resolution.**
   At low resolution the captured CAPTCHA image is unusable, and recognition fails even with a working solver connection.

5. **Check the hosts file.**
   Pirated or repacked updaters write domain blocks into Windows. Delete `C:\Windows\System32\drivers\etc\hosts`, then reopen Aion Updater.

### Warning

> Machines that have run pirated builds are **hardware-banned** from all aion.onl products. Buying a legitimate key afterwards does not lift the ban, and the affected key is banned as well.

## Gear upgrading and Kinah spending

### Q: How do I stop the helper from automatically upgrading my items?

A: There is a toggle for auto-enhance, and a gear-score cap you set yourself. Both are in the control panel (central console). The developer's own wording: *"The auto-enhance feature includes a toggle switch. You can configure it to stop enhancing once it reaches level 1100. If you want to earn money quickly, you can adjust these settings in the central console."*

So you can either switch auto-enhance off completely, or leave it on and set the gear score at which it stops. Once the character reaches that cap, nothing is enhanced any more — including talismans.

### Q: What does auto-enhance do if I leave it on?

A: Enhancement is based on the item's ItemLevel, not on item quality:

| ItemLevel | Enhanced to |
| --- | --- |
| ≥ 50 | +10 |
| ≥ 43 | +7 |
| ≥ 40 | +5 |
| ≥ 30 | +3 |
| < 30 | not enhanced |

Ancient stones are enhanced to +1.

### Q: Why does the helper keep spending my Kinah on upgrades?

A: Before the 19–20 October updates, enhancement was quality-based: blue gear was pushed to +7 and gold gear was enhanced whenever it was equipped, which drained Kinah and stones. Players complained about exactly this, and the item-level rule above replaced it. If you still see excessive spending, check the cap setting in the control panel — the behaviour differs between builds.

## Accounts, compatibility, and risk

### Q: Is it safe to use the software on my main account?

A: Chat participants warned that using the software carries a ban risk and advised people who are not willing to accept that risk not to use it. The chat cannot guarantee whether or when an account will be restricted.

### Q: Can I run multiple game clients at the same time?

A: Participants described VK multi-boxer as a separate tool for running multiple clients and warned that multi-client use may carry a ban risk. They did not recommend it. The chat did not provide a method that guarantees safe multi-client use.

### Q: Will a ban on one account automatically affect my other accounts?

A: One participant reported that two of their four accounts were banned, but this is an individual report—not an official rule or a guarantee about how account restrictions are applied.

### Q: Can the software be used with the EU server?

A: A chat response said that the EU server was supported and advised running Aion Updater. Because compatibility can change, check for a current confirmation after game updates.

### Q: How do I log in with Purple, Steam, or Google?

A: A participant said that if you can log in to Purple manually, the control panel should be able to log in as well. Steam and Google accounts require their corresponding authorization method.

*(This is a chat-reported support answer; account flows may vary by client or region.)*

## Other reported issues

### Q: Automatic gathering skips Odyle nodes. Is there a workaround?

A: A user reported that the software skipped many Odyle nodes. The chat did not contain a confirmed workaround.

### Q: The CAPTCHA solver keeps confusing lowercase "l" with uppercase "I." What should I report?

A: Report the specific characters that are being confused and include an example of the failure if available. The chat identified this as a recognition issue, but did not provide a verified user-side fix.

### Q: The CAPTCHA or verification process fails frequently. What was suggested?

A: A support response suggested increasing the game-window resolution so the captured image is not too small, and checking that the network can reach the verification server. The chat contains only a single report for this issue, so treat these as initial checks rather than a confirmed general fix.

### Q: The task flow or a specific dungeon exit is broken after an update. What should I check?

A: Check whether you have the update that mentions the relevant fix. One announcement listed fixes for task data after character switching and for failing to exit a level-8 Demon dungeon.

*(The update note only confirms that those specific bugs were addressed; it does not establish a fix for unrelated dungeon problems.)*

### Q: I reached the upgrade limit, but the software is still upgrading talismans. Is that expected?

A: An update announcement said that once the equipment level reaches the control-panel upgrade limit, talismans should no longer be upgraded automatically.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
