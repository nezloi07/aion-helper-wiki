# Aion 2 account status monitor: bans, captchas, auto-recovery
The Control Center checks every account's status in the background: normal, banned, captcha needed, restricted or session expired. For a banned account, open its details to see the reason and time left, and use “Assist Unban” to open the official unban page.

...

## What it does
* Account status: Normal, Banned, Captcha, Restricted, Session Expired and more
* Running status: logging in, starting, in game, Queued, Resting, restarting and more, along with whether it is in combat, gathering, on Auto Task or in a dungeon
* Auction access time left, and the account name turns red when it is about to expire
* The details page shows the ban reason, length, time left and unban time
* Assist Unban: opens the official unban page, clicks verify and fills in the email for you
* Restarts the game after a crash and resumes the work it was doing

...

## Settings explained

| Setting | What it does |
| --- | --- |
| Account Status | Checked automatically in the background. Nothing to do. |
| Assist Unban | Opens the official unban page and fills it in. You have to complete the image captcha yourself. |
| Bound characters › refresh list / sync current server | Updates each character's level, combat power, Kinah, daily Kinah cap progress and gathering time. |

## Good to know
* The official unban page allows at most 8 attempts per day from the same network.
* A banned account's whole row turns grey, so you can spot it at a glance.

## Related features
[🖥 **Control Center: multi-account management** Add accounts, log in in batches, and see every account's status in one table.](control-center.md) [◎ **Guardian verification and free AI recognition** Keep the Control Center open to pass verification automatically, free and without a ClientKey.](captcha.md) [📄 **Daily records and run logs** See every account's workflow by date, and check logs for a single

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
