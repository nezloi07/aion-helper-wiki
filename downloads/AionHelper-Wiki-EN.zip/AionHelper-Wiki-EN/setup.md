# Aion Helper setup checklist and crash fixes: resolution, runtime
Before the first install, set your game resolution (windowed and fullscreen mode are both supported). If the game crashes, work through the two fixes below.

## How to use it
1. Windowed and fullscreen mode both work - use whichever you prefer
2. Adjust to your preferred resolution (no specific limit, set based on your preference)
3. Confirm settings are correct, then run the updater to install the bot

...

## Good to know
* Please set your game resolution BEFORE using the updater!
* The bot locks the current game resolution after installation.
* Re-run the Updater after every game update. Otherwise the helper shows “Update required” and will not work for the moment.

## Related features
[🔑 **Updater and card key login** Install the helper, log in your card key, and re-run after every game update.](updater.md) [⌨ **Helper menu and hotkeys** Press F10 to open the menu, and use Ctrl hotkeys to start or stop.](helper-menu.md) [🌐 **Multiple servers and game paths** Taiwan, Korea, Global and Steam all work. Set paths and language in the Control Center.](servers.md)
Download Aion Helper and follow the steps above to get started.
[Download Now](https://goo.su/4P1Ld)
Aion Helper
Official Aion2 cheat and bot website. The most powerful hack tool with auto-battle, auto-quest, auto-gathering, and auto-leveling features for Aion2

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://goo.su/4P1Ld) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
