Tick “Automatically Complete Daily Quests” on the “Auto Task” tab. Whenever a daily quest is available, the helper handles it first, then goes back to side quests and other work.

- Level 45 · combat power 1000+

## Where to find it

1. F10 Helper menu
2. Auto Task
3. Daily Quests
4. Automatically Complete Daily Quests

This switch is synced with the Control Center. Change it on either side and it takes effect.

## What it does

- Accepts and completes daily quests every day
- Dailies take priority over side quests, so any available daily is done first
- With several accounts, combine it with the Control Center's Daily Activities so every character runs its dailies

## How to use it

1. Make sure your character is level 45 with combat power of 1000 or more.
2. Press F10 to open “Auto Task” and tick “Automatically Complete Daily Quests” under “Daily Quests”.
3. Click “Start Task”. The helper deals with daily quests first.
4. With several accounts, add an “Auto quest” step in the Control Center's “Daily Activities” and every character will run its dailies.

## Settings explained

| Setting | What it does |
| --- | --- |
| Automatically Complete Daily Quests | Off by default. When on, Auto Task handles daily quests first. |

## Good to know

- How far dailies get depends on your character and on which quests the game offers that day.
- If your level or combat power is not high enough yet, build the character up with Auto Task and Auto Combat first.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
