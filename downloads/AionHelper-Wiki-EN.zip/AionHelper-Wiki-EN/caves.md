After the main and side quests are done, Auto Task keeps going and explores caves that give rewards, collecting Guardian points and skill points so you do not have to hunt them down one by one.

- Elyos · Asmodians

## Where to find it

1. F10 Helper menu
2. Auto Task
3. Task Progress

Cave exploration is part of Auto Task. Starting Auto Task runs it in order, and “Exploration Cave Progress” shows how far along it is.

## What it does

- Both Elyos and Asmodians pick caves by reward, and only caves that give Guardian points or skill points are done
- A progress bar shows how many are done out of the total
- Shows how many caves are temporarily locked because a prerequisite quest is not finished
- Can be set to “Explore caves before dungeon quests” in the Control Center

## How to use it

1. Press F10 to open “Auto Task” and click “Start Task”.
2. When the main and side quests are finished, the helper moves on to exploring reward caves.
3. Check how many are left under “Task Progress › Exploration Cave Progress”.

## Settings explained

| Setting | What it does |
| --- | --- |
| Exploration Cave Progress | Completed / total. |
| Caves with unmet prerequisite quests | The number of caves you cannot enter until a prerequisite quest is done. |
| Explore caves before dungeon quests (Control Center › Settings › Auto Task) | Takes care of caves first, then moves on to dungeon quests. |

## Good to know

- Before clearing Elyos caves, move your character to an Elyos map by hand.
- Caves that take too long are skipped automatically so the run does not get stuck. A few caves that need heavy dodging are not handled yet.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
