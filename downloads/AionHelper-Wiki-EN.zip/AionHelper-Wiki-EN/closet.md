See something you like? Click to wear it. Besides outfits, you can now change your weapon and your wings, and let the assistant shuffle your favorites in each one. An exclusive extra for All-Purpose Card users.

## Make the look your own

- Outfits: click a name and see your new look right away.
- Weapons: only weapons your class can use are listed, so every choice fits.
- Wings: wings for your race are listed. Spread your wings, glide or fly to see them.
- Shuffle each part: outfits, weapons and wings each have their own random switch. Shuffle just one or all three; random only picks what you checked.
- Keep your choices: each character keeps its own wardrobe.

## A new scene, the look you love

Want to keep one look? Leave random off and the assistant puts it back on after you change scenes. Turn random on and it picks from your checked favorites for a little variety on your next adventure.

## Start in three steps

1. Open Free Appearance and check Enable free appearance.
2. On the Outfits, Weapons or Wings tab, click a name to try the new look.
3. For more variety, check a few favorites on a tab and turn on Random outfit, Random weapon or Random wings.

## Exclusive to the All-Purpose Card

Enter the game and open Free Appearance in the assistant to start browsing. The feature is off by default, so you decide when to turn it on.

## About Free Appearance

Your new look only shows on your own screen; other players still see your original appearance. It does not change equipment stats or purchase or permanently unlock shop items.

## Ready for a new look?

Read the appearance update · [Download the assistant](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · [Explore more features](Home.md)

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
