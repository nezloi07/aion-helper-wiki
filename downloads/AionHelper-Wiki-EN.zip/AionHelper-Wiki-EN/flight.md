There is nothing to set up here. Auto Task and Auto Gather decide when to take off and whether your flight energy is enough, drink flight potions when energy is low, and use a return scroll to get unstuck.

- Works automatically, no setup

## Where to find it

1. Auto Task / Auto Gather
2. Works automatically

## What it does

- Improves takeoff timing during quests and gathering
- Uses a flight potion automatically when flight energy drops below 15%
- Recognizes the flight potions in your inventory
- Restocks potions automatically when needed
- Uses a return scroll automatically when stuck

## How to use it

1. Keep flight potions and return scrolls in your inventory.
2. Just run Auto Task or Auto Gather as usual.

## Good to know

- If your flight energy is not enough to reach the target, it waits for the energy to recover before taking off.
- While a return scroll is casting, the helper pauses everything else so the cast is not interrupted.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
