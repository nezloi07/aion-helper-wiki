# Aion Helper supported servers: Taiwan, Korea, Global and Steam
Aion Helper supports the Taiwan, Korea, Global and Steam Global servers. The helper detects which server your client belongs to. When you launch several accounts through the Control Center, you can set the game path and game language for each server.

...

## What it does
* Detects Taiwan, Korea and Global (including Steam) clients automatically
* When you add an account, its server is detected from the registration country. Global accounts can pick North America - East, North America - West, Europe, South America or Asia
* Set a separate game path for Taiwan, Korea and Global. Leave it empty and the Control Center searches for it
* Choose the game language: Traditional Chinese, Korean or English
* Both the Control Center and the helper menu support Simplified Chinese, English and Korean

## How to use it
1. Log in your card key in the Updater. It installs the helper into every game folder it finds, Steam included.
2. If you use several accounts, open Control Center › Settings › General and check the game path of each server. If one is missing, click “Browse” and select it by hand.
3. Pick a language in “Game Language Selection”. It applies the next time you launch the game.
4. When adding an account, make sure the server was detected correctly.

...

## Settings explained

| Setting | What it does |
| --- | --- |
| Language Settings | The Control Center's display language. Restart the Control Center after changing it. |
| Game Language Selection | The language of the game client. The default is Traditional Chinese, and it applies the next time you launch the game. |
| Game Path Settings | One path each for Taiwan, Korea and Global. Click “Browse” to pick one, or leave it empty to search automatically. |
| Global server region | Choose your region when adding a Global account. |

...

## Related features
[🔑 **Updater and card key login** Install the helper, log in your card key, and re-run after every game update.](updater.md) [🖥 **Control Center: multi-account management** Add accounts, log in in batches, and see every account's status in one table.](control-center.md)
Download Aion Helper and follow the steps above to get started.
[Download Now](https://goo.su/4P1Ld) [Setup checklist & crash fixes →](setup.md)
Aion Helper

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://goo.su/4P1Ld) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
