Before the first install, set your game resolution (windowed and fullscreen mode are both supported). If the game crashes, work through the two fixes below.

## How to use it

1. Windowed and fullscreen mode both work - use whichever you prefer
2. Adjust to your preferred resolution (no specific limit, set based on your preference)
3. Confirm settings are correct, then run the updater to install the bot

## Game Crash Solutions

| Fix | What to do |
| --- | --- |
| Solution 1: Install Runtime Libraries | The game requires complete VC++ runtime library support — Download and install [VC++ Redistributable](https://aka.ms/vs/17/release/vc_redist.x64.exe); Restart the game after installation |
| Solution 2: Disable GPU Hardware Acceleration | GPU hardware acceleration may conflict with the bot — Open Windows System Settings; Find "Hardware-accelerated GPU scheduling" in Display or Graphics settings; Turn it off and restart your computer |

## Good to know

- Please set your game resolution BEFORE using the updater!
- The bot locks the current game resolution after installation.
- Re-run the Updater after every game update. Otherwise the helper shows “Update required” and will not work for the moment.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
