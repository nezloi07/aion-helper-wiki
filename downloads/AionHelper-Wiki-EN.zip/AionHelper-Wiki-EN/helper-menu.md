Aion Helper is the in-game window of Aion Helper. Press F10 in AION 2 to open it: auto quests, gathering, combat, dungeons, free appearance and settings, one tab each.

## Where to find it

1. Enter the game
2. Press F10
3. Aion Helper

The window title shows your remaining card time, how long it has been running and what it is doing. The tab that is currently running turns green.

## What it does

- Six tabs: Auto Task, Auto Gather, Auto Combat, Auto Dungeon, Free Appearance (All-in-One card) and General Config
- Every tab has a start/stop button at the top, with its hotkey shown next to it
- Switch the menu language between Simplified Chinese, English and Korean instantly
- If a feature is temporarily unavailable after a game update, the menu lists it and retries automatically

## How to use it

1. Once your character is in the game, press F10. The menu appears in the top-left corner and can be dragged anywhere.
2. Switch to the tab you want and adjust the settings as needed.
3. Click the start button at the top of the tab, or just press its hotkey.
4. Press the hotkey again or click the stop button to finish. F10 hides the menu at any time.

## Settings explained

| Setting | What it does |
| --- | --- |
| F10 | Show or hide the helper menu. |
| Ctrl+T | Start or stop Auto Task. |
| Ctrl+G | Start or stop Auto Gather. |
| Ctrl+B | Start or stop Auto Combat. |
| Ctrl+D | Start or stop Auto Dungeon. |
| General Config › Language 语言 언어 | Change the menu language. It takes effect immediately. |

## Good to know

- Auto Task, Auto Gather and Auto Combat can only run one at a time. Starting one stops the other two.
- If you see “Update required”, close the game, run the Updater, then go back in.
- Inside Krao Cave, the gathering and combat tabs are hidden for now, so only Auto Task or Auto Dungeon can be used.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
