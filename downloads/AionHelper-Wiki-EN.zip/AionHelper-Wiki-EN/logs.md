# Aion 2 Control Center logs: daily records and run logs, export

Want to know what happened while you were away? The Control Center's “Daily Records” collects how the workflow ran for every account, and you can right-click an account to see its run log and daily log.

## Where to find it

1. Control Center
2. Daily Records

## What it does

- A global record of the daily workflow: work, gathering, auto combat, character switching and wrap-up
- Browse by date, refreshed automatically every 5 seconds, showing up to 1000 entries
- Export to a txt file
- Right-click an account › View Logs: run log and daily log
- Filter logs by Info, Warning, Error and Debug

## How to use it

1. Click “Daily Records” on the left and pick a date.
2. Click the export button to save a copy.
3. To look at one account, right-click it on the Accounts page › View Logs › view the run log or the daily log.

## Settings explained

| Setting | What it does |
|---|---|
| Date / Refresh / export | Pick the date to look at, refresh by hand, or export to a txt file. |
| Auto Scroll | The log window scrolls to the newest line on its own. |
| Info / Warning / Error / Debug | Filter logs by level. |
| Clear Logs | Clears the logs in the current window. |

## Good to know

- Times in Daily Records are shown in Beijing time.
- Attach your logs when you report a problem to support. It makes the cause much easier to find. The feedback channel is Discord.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://goo.su/4P1Ld) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
