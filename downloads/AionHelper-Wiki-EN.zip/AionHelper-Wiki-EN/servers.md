Aion Helper supports the Taiwan, Korea, Global and Steam Global servers. The helper detects which server your client belongs to. When you launch several accounts through the Control Center, you can set the game path and game language for each server.

- Taiwan
- Korea
- Global
- Steam

## Where to find it

1. Control Center
2. ⚙ Settings
3. General

## What it does

- Detects Taiwan, Korea and Global (including Steam) clients automatically
- When you add an account, its server is detected from the registration country. Global accounts can pick North America - East, North America - West, Europe, South America or Asia
- Set a separate game path for Taiwan, Korea and Global. Leave it empty and the Control Center searches for it
- Choose the game language: Traditional Chinese, Korean or English
- Both the Control Center and the helper menu support Simplified Chinese, English and Korean

## How to use it

1. Log in your card key in the Updater. It installs the helper into every game folder it finds, Steam included.
2. If you use several accounts, open Control Center › Settings › General and check the game path of each server. If one is missing, click “Browse” and select it by hand.
3. Pick a language in “Game Language Selection”. It applies the next time you launch the game.
4. When adding an account, make sure the server was detected correctly. For Global accounts, also choose the region.

## Settings explained

| Setting | What it does |
| --- | --- |
| Language Settings | The Control Center's display language. Restart the Control Center after changing it. |
| Game Language Selection | The language of the game client. The default is Traditional Chinese, and it applies the next time you launch the game. |
| Game Path Settings | One path each for Taiwan, Korea and Global. Click “Browse” to pick one, or leave it empty to search automatically. |
| Global server region | Choose your region when adding a Global account. |

## Good to know

- Your card key must cover the server you play on. If your card does not support Korea but you open the Korea client, the menu shows “Region Restriction Warning”. Switch to a card that supports that server.
- Multi-account launching needs the client downloaded through Purple. If you are a Steam player running a single game, just enter the game and press F10.
- If a server's client is not installed yet, starting an account on that server prompts you to “Set game path”.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software-hlp/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
