# Aion 2 multi-account online schedule: random work and rest times
Turn on the work schedule to cap how many accounts are online at once. Each account works for a random length of time, goes offline to rest, then queues up to log back in, which makes the pattern look more natural.

...

## What it does
* Up to 1–16 accounts online at once, and the rest wait in a queue
* Each work period is random within your range, and the game closes automatically when it is up
* Each rest period is random too, and the account rejoins the queue when it ends
* If the game crashes it restarts automatically, and an account that keeps failing is paused so its slot goes to another account
* The account list shows countdowns like “Work 45/180 min”

## How to use it
1. Open Control Center › Settings › Work Schedule and tick “Enable work schedule”.
2. Choose the number for “Max accounts online”.
3. Drag the sliders to set the work duration range and the rest duration range, then save.
4. Start daily activities or a batch launch, and accounts rotate automatically by slot and time.

## Settings explained

| Setting | What it does |
| --- | --- |
| Enable work schedule | Off by default. When off, there is no limit and accounts never go offline by themselves. |
| Max accounts online | 1–16, 10 by default. Accounts over the limit show “Queued” or “Waiting for slot”. |
| Work duration range | 1–24 hours, 3–5 hours by default, random each time. |
| Rest duration range | 1–24 hours, 1–2 hours by default, random each time. |

## Good to know
* Crash restarts and pausing failing accounts are built in. You do not need to turn them on.
* Set the number of accounts online according to your computer. If it is not very powerful, fewer accounts run more steadily.

## Related features
[↝ **Daily Activities planner** Arrange quests, Kinah farming, gathering and character switching into a workflow that rotates accounts.](daily-activities.md) [🛡 **Account status and auto-recovery** Checks for bans and problems automatically, recovers from disconnects automatically.](account-status.md)

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
