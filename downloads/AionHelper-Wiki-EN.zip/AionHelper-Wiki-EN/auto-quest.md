Click “Start Task” on the “Auto Task” tab and the helper completes your main and side quests for you: pathing, dialogue, fighting and cutscenes are all handled. At max level it keeps going with valuable side quests and reward caves.

- Elyos · Asmodians, all classes

## Where to find it

1. F10 Helper menu
2. Auto Task
3. Start Task

Hotkey: Ctrl+T. If the Control Center creates characters for you, pick the race and class under “Settings › Auto Task” in the Control Center.

## What it does

- Runs the main story up to level 45. Every Elyos and Asmodian class is supported, and the race is detected automatically
- At max level, clears valuable side quests first, then explores caves that give rewards
- “Task Progress” shows your side quest progress and cave exploration progress live
- Can complete daily quests along the way
- Once the main story is done and you are level 45, it switches to gathering by default so no online time is wasted

## How to use it

1. Enter the game, press F10 to open the helper menu and switch to “Auto Task”.
2. Tick “Automatically Complete Daily Quests” if you want it.
3. Click “Start Task” (or press Ctrl+T). When the tab turns green, it is running.
4. Check side quest and cave progress under “Task Progress”. Click “Stop Task” whenever you want to stop.

## Settings explained

| Setting | What it does |
| --- | --- |
| Start Task / Stop Task | Starts or ends Auto Task. Hotkey: Ctrl+T. |
| Task Progress | Shows side quest progress, cave exploration progress, and how many caves are temporarily locked because a prerequisite quest is not done. |
| Automatically Complete Daily Quests | When ticked, daily quests are handled first. See “Auto daily quests” for details. |
| Switch to gathering after tasks complete (Control Center › Settings › Auto Task) | Whether to switch to gathering once everything is done at max level. On by default. |
| Race / Class (Control Center › Settings › Auto Task) | The race and class used when a new character is created automatically. The class can also be set to “Random”. |
| Clear side quests before dungeon quests / Explore caves before dungeon quests (Control Center › Settings › Auto Task) | Takes care of side quests or caves before it starts on dungeon quests. |

## Good to know

- A few side quests and caves with complicated mechanics are not completed automatically.
- Steam Global has no Growth Support system, so those reward steps are skipped automatically and leveling is not affected.
- Your card key must include Auto Task access. Without it the button is greyed out and tells you why.
- New to the game? Our AION 2 guide for beginners covers download, region, server and your first steps before you turn on auto quests.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
