“Auto Dungeon” can run Krao Cave for you: it clears monsters, fights bosses, dodges lethal skills and collects the reward. It is a beta for now. It is normally an All-in-One card feature, but it is free for everyone during testing so we can collect feedback.

- Beta
- Free for everyone during testing

## Where to find it

1. F10 Helper menu
2. Auto Dungeon
3. Start Dungeon

Hotkey: Ctrl+D.

## What it does

- Moves through the run on its own: prerequisite enemy, First Boss, Second Boss, clear mobs, Imprint, Final Boss, collect reward
- Dodges lethal skills during fights
- Shows live progress and combat state (Wait for party / Fighting / Evading)

## How to use it

1. Bring a character with combat power of 1100 or more into Krao Cave.
2. Press F10 to open “Auto Dungeon” and click “Start Dungeon” (or press Ctrl+D).
3. Watch progress on the tab, and click “Stop Dungeon” any time to take over yourself.

## Settings explained

| Setting | What it does |
| --- | --- |
| Start Dungeon / Stop Dungeon | Starts or ends Auto Dungeon. Hotkey: Ctrl+D. |
| Progress | Which step it is on, such as First Boss, Imprint, Final Boss or Collect reward. |
| Combat state | Waiting for the party, fighting or evading a skill. |

## Good to know

- Only Krao Cave is supported for now. For normal difficulty, just use “Auto Task”.
- Combat power of 1100 or higher is recommended.
- Still choosing a main for dungeons? The AION 2 class tier list compares all 8 Global classes for PvE groups, PvP and solo play.
- Your character is not revived automatically after dying. Choose when to revive yourself.
- Farming Arcana cards? The AION 2 dungeon guide covers Transcendence tiers, Odyle Energy costs and what Arcana do.
- Inside Krao Cave, only Auto Task or Auto Dungeon can be used, and the gathering and combat tabs are hidden for now.
- The beta cannot fully replace manual play yet, and it will keep improving. Auto account switching, auto party and more are coming later.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
