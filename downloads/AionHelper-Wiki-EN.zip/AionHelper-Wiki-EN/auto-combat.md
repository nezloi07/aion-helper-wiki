# Aion 2 auto combat bot: skill rotation, pulling, rapid fire setup

“Auto Combat” uses your class's skills automatically and works with patrol points to find monsters, pull them and loot. It is made for grinding in the field: farming Kinah up to the daily cap, experience and pets.

- All classes

## Where to find it

1. F10 Helper menu
2. Auto Combat
3. Start Combat
Hotkey: Ctrl+B. The in-game action mode must be set to “Aion1”, or auto-attack may not work.

## What it does

- Skill rotation for every class, including Stigma skills stacked on the hotbar
- Active pull: gathers monsters together before fighting, great for area-damage classes
- Rapid fire mode: high-damage ranged classes use basic attacks only and attack while moving
- Allow kill stealing: also attack monsters other players pulled, useful when there are few monsters and many players
- Does not go after bosses on its own while grinding in the field, so pet farming and the daily Kinah cap are not disturbed
- Switches to gathering when you are close to the day's Kinah cap

## How to use it

1. Change the action mode to “Aion1” in the game settings.
2. Go to your grinding spot and press F10 to open “Auto Combat”.
3. Under “Patrol Settings”, click “Smart Plan” to build a route, or add points by hand.
4. Adjust “Rapid Fire Mode”, “Active Pull” and “Allow Kill Stealing” for your class.
5. Click “Start Combat” (or press Ctrl+B).

## Settings explained

| Setting | What it does |
|---|---|
| Rapid Fire Mode | Off by default. Uses basic attacks only and attacks while moving, suited to high-damage ranged classes. The skill rotation is not used while this is on. |
| Active Pull | On by default. Gathers monsters together before fighting. Not recommended for melee classes. |
| Pull Distance (m) | 15 to 25 meters, 25 by default. The larger it is, the more monsters you pull. Below 20 meters, it basically pulls on the spot. |
| Allow Kill Stealing | Off by default. Also attacks monsters pulled by other players, suited to well-geared characters when monsters are few and players many. You pull fewer monsters while it is on. |
| Switch to gathering when daily Kina reaches 95% | On by default. When you are close to the day's Kinah cap from field monsters, it switches to gathering. |

## Good to know

- Automatic equipment extraction is a built-in game feature. Set it up in your in-game inventory.
- While the map changes, the tab only shows “Loading scene...”. Just wait a moment.
- Patrol routes, monster filter, smart pet farming and Abyss grinding each have their own guide. See the related features below.
- Some classes farm alone much faster than others. The [AION 2 class tier list](/blog/2025/10/01/aion2-aion2-your-ultimate-beginner-class-selec-2592/) ranks all 8 Global classes for solo play, PvE and PvP.
- Playing a Cleric? The [AION 2 Cleric guide](/blog/2026/10/17/aion2-cleric-guide-en/) explains which skills belong in the in-game macro and which heals to keep on your own keys.
- Playing a Chanter? The [AION 2 Chanter guide](/blog/2025/10/16/aion2-aion2-unlocking-the-hidden-potential-of-5128/) covers core stigmas, Dark Crush at 16 and why melee Chanters should leave Active Pull off.
- Playing a Templar? The [AION 2 Templar guide](/blog/2026/10/19/aion2-templar-guide-en/) explains why Judgment goes to 16 first, how to split 4 stigma slots and how to hold aggro.
- Playing an Assassin? The [AION 2 Assassin guide](/blog/2025/10/03/aion2-mastering-the-art-of-stealth-a-comprehen-2901/) covers the 4 PvE stigmas, Heart Gore to 16 and a macro that keeps it firing.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
