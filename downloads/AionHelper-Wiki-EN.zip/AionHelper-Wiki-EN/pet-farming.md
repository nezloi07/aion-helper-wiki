# Aion 2 auto pet farming: switches spots, next pet when done

Turn on “Auto-switch pet farming spot” and the helper finds the pets on this map that are not maxed yet, goes to the nearest spot and keeps farming there. When one pet is done, it moves on to the next.

## Where to find it

1. F10 Helper menu
2. Auto Combat
3. Smart Pet Farming

## What it does

- Finds the pets on the current map that are not at max level yet
- Heads for the nearest available spot first
- When a spot is finished, it switches to the next one automatically
- One spot can be used to farm several pets at the same time
- Does not go after bosses on its own in the field, so pet farming is not disturbed

## How to use it

1. Go to the map where you want to farm pets and press F10 to open “Auto Combat”.
2. Under “Smart Pet Farming”, tick “Auto-switch pet farming spot”.
3. Click “Start Combat”.

## Settings explained

| Setting | What it does |
|---|---|
| Auto-switch pet farming spot | Off by default. When on, pet farming takes over patrol points and the monster filter. |

## Good to know

- While it is on, “Patrol Settings” and “Monster Filter” are hidden. Turn pet farming off and they come back.
- Once every pet on this map is maxed, move to another map and continue.
- Pet farming takes priority over “Switch to gathering when daily Kina reaches 95%”.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
