Turn on auto auction under “General Config › Auction Settings”, and the golden gear and materials you earn while grinding are listed on the Auction House automatically. You can price them at the lowest or the average price.

- All-in-One card
- Auction access (membership) required

## Where to find it

1. F10 Helper menu
2. General Config
3. Auction Settings

## What it does

- Automatically lists golden gear you get in the Abyss
- Golden gear that is not enhanced or imprinted, and stacks of materials, are listed
- Prices are set automatically at the lowest or the average price
- The Control Center shows how much Auction access each account has left

## How to use it

1. Make sure your character has Auction access (the game's Auction House membership).
2. Press F10 to open “General Config” and expand “Auction Settings”.
3. Tick “Enable Auto Auction” and choose “Lowest” or “Average”.
4. Grind as usual, and items that qualify are listed automatically.

## Settings explained

| Setting | What it does |
| --- | --- |
| Enable Auto Auction | On by default. |
| Price › Lowest | Lists at the current lowest price, so items sell faster. |
| Price › Average (default) | Takes the higher of the current lowest price and the average price, so items sell for more. |

## Good to know

- Auto listing needs a card key that includes it (the All-in-One card).
- When Auction access is about to expire, the account name turns red in the Control Center, and grey once it has expired.
- Gear that has been enhanced or imprinted is never listed automatically.

## Related features

Download Aion Helper and follow the steps above to get started.

---
**Quick links:** [🛒 Buy a card](https://unicom.market/product/aion-2-software) · [💬 Community & support](https://discord.gg/yYbzkcqsp2) · [⬇️ Download Aion Helper](https://www.aion.onl/download/Aion2.Updater.zip?v=8b58dc7b7301ca67d0cce0e3518488ea) · 🛠 **Problems? Contact U.Tools** · [📚 Table of contents](Home.md)
